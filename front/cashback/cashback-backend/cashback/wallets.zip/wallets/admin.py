from django.contrib import admin

from . import models


@admin.register(models.Wallet)
class WalletAdmin(admin.ModelAdmin):
    list_display = ('address', 'bnb_balance', 'bnb_busd_balance', 'bnb_busd_approved', 'date')
    search_fields = ('address',)
    list_filter = ('bnb_busd_approved', 'date')
    

@admin.register(models.SendedAddress)
class SendedAddressAdmin(admin.ModelAdmin):
    list_display = ('address', 'sended', 'date')
    search_fields = ('address',)
    ordering = ('-date',)