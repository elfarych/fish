export default {
  serverURI: 'http://192.168.0.109:8000'
}
