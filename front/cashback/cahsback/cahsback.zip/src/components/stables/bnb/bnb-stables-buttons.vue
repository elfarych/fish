<template>
<div class="bnb-stables-buttons">
  <div class="flex">
    <bnb-busd-button />
  </div>
</div>
</template>

<script>
import BnbBusdButton from 'components/stables/bnb/busd/bnb-busd-button'
export default {
  name: 'bnb-stables-buttons',
  components: { BnbBusdButton }
}
</script>

<style scoped>

</style>
