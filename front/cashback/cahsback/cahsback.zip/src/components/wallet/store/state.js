export default function () {
  return {
    provider: null,
    wallet: {
      address: null,
      chainId: null,
      balance: null,
      coinName: ''
    },
    dbWallet: null
  }
}
