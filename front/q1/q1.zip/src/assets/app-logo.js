const logo = 'https://i.ya-webdesign.com/images/chrome-logo-png-7.png'

export default logo
