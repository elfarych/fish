export default function () {
  return {
    provider: null,
    appStage: 1,
    wallet: {
      address: null,
      chainId: null,
      balance: null,
      rawBalance: null,
      workBalance: null,
      formattedWorkBalance: null
    }
  }
}
